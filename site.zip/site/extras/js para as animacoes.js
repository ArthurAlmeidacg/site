
function randomArr(n){
    var returnArr = [];
    resetAnimation();
    for (var i=0; i<n; i++){
      returnArr.push(Math.floor(Math.random()*300+1));
    }
    return returnArr;
  }
  
  var globB = 0;
  var globG = 0;
  function updateHtml(arr, temp=false, globalArrLen=false){
    var htmlStr = "";
    var target = temp ? "#temp-grid" : "#grid-container";
    var arrLen = globalArrLen ? globalArrLen : arr.length;
    for (var i=0; i<arr.length; i++){
      htmlStr += '<div class="grid-element" id="bar'+i+'" style="height:' + arr[i]/(temp+1) + 'px; background-color: rgb('+Math.floor(arr[i]/1.57)+','+globG+','+globB+');"></div>';
    }
    $(target).css("grid-template-columns", "repeat("+arrLen+",1fr)");
    $(target).html(htmlStr);
  }
  
  
  var globalArr;
  var globalArrCopy;
  var arrLength = 5; // se colocar 0 aqui quando carrega a pagina fica sim sem nenhum array mostrnado porem o botao de new random array nao funciona
  var animDelay = 200;
  $("#count-input").change(() => {
    if ($("#count-input").val() > 1000) $("#count-input").val(1000);
    arrLength = $("#count-input").val();
    updateGlobalArrays();
  });
  $("#anim-delay").change(() => {
    if ($("#anim-delay").val() < 0) $("#anim-delay").val(0);
    animDelay = $("#anim-delay").val();
    //console.log(animDelay);
  });
  
  
  function updateGlobalArrays(arr=undefined){
    globalArr = arr ? arr : randomArr(arrLength);
    globalArrCopy = [];
    for (var i = 0; i<globalArr.length; i++){
      globalArrCopy.push(globalArr[i]);
    }
    updateHtml(globalArr);
  }
  
  /*
  var width;
  var img = new Image();
  img.onload = function() {
    $("#finicky").css("width", (this.width+2)+"px");
    console.log(this.width);
  }
  img.src = 'https://en.wikipedia.org/wiki/Heapsort#/media/File:Heapsort-example.gif'; */
  
  
  $("#input-arr").on("click", () => {
    $("#popup").css("display", "inherit");
    $("#backdrop").css("background-color", "rgba(0,0,0,0.8)");
    $("#backdrop").css("z-index", "8");
  });
  
  $("#close-popup").on("click", () => {
    var rawinput = $("#arr-input").val();
    $("#popup").css("display", "none");
    $("#backdrop").css("background-color", "rgba(0,0,0,0)");
    $("#backdrop").css("z-index", "-50");
    var input = rawinput.match(/[0-9]+/g).map((x) => parseInt(x));
    var scale = 300/Math.max(...input);
    input = input.map((x) => x*scale);
    updateGlobalArrays(input);
  });
  
  function disableHelp(){
    $("#help-popup").css("display", "none");
    $("#backdrop").css("background-color", "rgba(0,0,0,0)");
    $("#backdrop").css("z-index", "-50");
    helping = false;
  }
  
  var helping = false;
  $("#help-button").on("click", () => {
    if (!helping){
    $("#help-popup").css("display", "inherit");
    $("#backdrop").css("background-color", "rgba(0,0,0,0.8)");
    $("#backdrop").css("z-index", "5");
    helping = true;
    } else {
    disableHelp();
    }
  });
  
  $("#backdrop").on("click", () =>{
    if (helping) disableHelp();
  });
  
  updateGlobalArrays();
  $("#reload").on("click", () => updateGlobalArrays());
  
  // function mergeIntoArr(arr1, arr2, s){
  // 	for (var i=s; i<arr2.length+s; i++){
  // 		arr1[i] = arr2[i-s];
  // 	}
  // 	return arr1;
  // }
  //console.log(mergeIntoArr([6,2,19,7,1],[1,7],3));
  
  //####### MERGE SORT
  // function mergeSort(s, f){
  // 	if (s == f){
  // 		return;
  // 	}
  // 	var m = Math.floor((s+f)/2);
  // 	mergeSort(s, m);
  // 	mergeSort(m+1, f);
  // 	globalArr = merge(globalArr, s,f);
  // }
  
  //var stepNum = 0;
  
  // function merge(arr, s, f){
  // 	var returnArr = [];
  // 	var m = (f+s)/2;
  // 	var count1=Math.floor(m+1);
  // 	var count2=s;
  
  // 	while (count1<=f && count2<=m){
  // 		//console.log("arr[count1]: " + arr[count1] + "; arr[count2]: " + arr[count2]);
  // 		if (arr[count1]>arr[count2]){
  // 			returnArr.push(arr[count2]);
  // 			count2++;
  // 		} else {
  // 			returnArr.push(arr[count1]);
  // 			count1++;
  // 		}
  // 	}
  
  // 	while (count1<=f){
  // 		returnArr.push(arr[count1]);
  // 		count1++;
  // 	}
  
  // 	while (count2<=m){
  // 		returnArr.push(arr[count2]);
  // 		count2++;
  // 	}
  //   //stepNum++;
  //   //console.log(stepNum);
  // 	//console.log("Merging " + arr + ", start="+s+", finish="+f+"; Result: " + returnArr + "; Result Arr: " + mergeIntoArr(arr, returnArr, s));
  //   returnArrVals.push(returnArr);
  //   sVals.push(s);
    
  // 	return mergeIntoArr(arr, returnArr, s);
  // }
  
  function move(arr, old_index, new_index){
      arr.splice(new_index, 0, arr.splice(old_index, 1)[0]);
  }
  
  function resetAnimation(clearTemp=true){
    animIndex = 0;
    returnArrVals = [];
    heapSwaps = [];
    heapArrCopies = [];
    sVals = [];
    insertKs = [];
    insertIs = [];
    insertArrCopies = [];
    tempReturnVals = [];
    bubbleArrCopies = [];
    bubbleColors = [];
    tempIndex = 0;
    if (clearTemp) updateHtml([], true);
    window.clearInterval(intervalId);
    console.log("Animation Completed");
  }
  
  var animIndex = 0;
  var tempIndex = 0;
  var intervalId;
  var returnArrVals = [];
  var tempReturnVals = [];
  var sVals = [];
  
  // function animHandler() {
  //   if (returnArrVals[animIndex+1] == undefined){
  //     updateHtml(globalArr);
  //     resetAnimation(false);
  //     return;
  //   }
  //   //console.log(mergeIntoArr(globalArrCopy, returnArrVals[animIndex], sVals[animIndex]));
  //   updateHtml(mergeIntoArr(globalArrCopy, returnArrVals[animIndex], sVals[animIndex]));
  //   if (returnArrVals[animIndex+1]) updateColors(sVals[animIndex+1],sVals[animIndex+1]+returnArrVals[animIndex+1].length);
  //   if (returnArrVals[animIndex+1][tempIndex]){
  //     tempReturnVals.push(returnArrVals[animIndex+1][tempIndex]);
  //     console.log(returnArrVals[animIndex+1] + ", " + returnArrVals[animIndex+1][tempIndex]);
  //     updateHtml(tempReturnVals, true, globalArrCopy.length);
  //     tempIndex++;
  //   } else {
      
  //     animIndex++;
  //     tempReturnVals = [];
  //     tempIndex = 0;
  //   }
  // } 
  
  function updateColors(s,f){
    var m = Math.floor((s+f)/2);
    for (var i=s; i<=m; i++){
      $("#bar"+i).css("background-color", "#0f0");
      //console.log("bar " + i);
    }
    for (var i=m+1; i<=f; i++){
      $("#bar"+i).css("background-color", "#00f");
      //console.log("bar " + i);
    }
  } 
  
  // $("#merge-sort").on("click", () => {
  //   $("h4").html("Temporary Array:");
  //   intervalId = window.setInterval(animHandler, animDelay);
  //   updateColors(0,1);
  //   mergeSort(0,globalArr.length-1);
  //   //console.log(globalArrCopy);
  //   //console.log(globalArr);
  // });
  
  // var insertIs = [];
  // var insertKs = [];
  // var insertArrCopies = [];
  // function insertionSort(arr){
  //   var tempArray;
  // 	for (var i=1; i<arr.length; i++){
  // 		for (var k=i-1; k>=0; k--){
  //       insertIs.push(i);
  //       insertKs.push(k);
  //       tempArray = [];
  //       for (var l=0; l<arr.length; l++){
  //         tempArray.push(arr[l]);
  //       }
  //       insertArrCopies.push(tempArray);
  // 			if (arr[k] < arr[i]){
  // 				move(arr,i,k+1);
  // 				break;
  // 			}
  // 			if (k == 0){
  // 				move(arr,i,0);
  // 			}
  // 		}
  // 	}
  // 	return arr;
  // }
  
  function updateTree(arr){
    var numCols = 1;
      var counter = 0;
      for (var i=0; i<arr.length; i++){
          if (counter>=numCols){
              counter = 0;
              numCols*=2;
          }
          counter++;
      }
    
    var htmlStr = "";
    for (var i=0; i<arr.length; i++){
      htmlStr += '<div class="grid-element tree-element bar'+i+'" style="background-color: rgb('+Math.floor(arr[i]/1.57)+','+globG+','+globB+');"></div>';
      //console.log(htmlStr);
    }
    $("#temp-grid").html(htmlStr);
    
    $("#temp-grid").css("grid-template-columns", "repeat("+numCols+",1fr)");
    $("#temp-grid").css("grid-gap", "2px");
    $(".tree-element").css("width", 100+"%"); //(1/numCols)*100
    $(".tree-element").css("height", "50px");
    var num = 0;
    var den = numCols;
    var count = 1;
    var divisions = 1;
    while (true){
      try {
        $(".bar"+(count-1)).css("grid-column",(num+1)+" / "+(den+1));
        if (numCols/divisions + num >= numCols){
          num = 0;
          divisions = 2*(divisions);
          den = numCols/divisions;
        } else {
          num += numCols/divisions;
          den += numCols/divisions;
        }
        if (num == numCols-1) break;
        count++;
      } catch(err) {
        console.log(err);
        break;
      }
    }
  }
  
  // function animHandlerInsert(){
  //   if (insertArrCopies[animIndex] == undefined){
  //     updateHtml(globalArr);
  //     resetAnimation();
  //     return;
  //   }
  //   updateHtml(insertArrCopies[animIndex]);
  //   $("#bar"+insertIs[animIndex]).css("background-color","#0f0");
  //   $("#bar"+insertKs[animIndex]).css("background-color","#00f");
  //   //if ()
  //   animIndex++;
  // }
  
  // $("#insertion-sort").on("click", () => {
  //   insertionSort(globalArr);
  //   intervalId = window.setInterval(animHandlerInsert, animDelay);
  //   //updateHtml(globalArr);
  // });
  
  $("#rainbow").on("click", () => {
    globB = Math.floor(Math.random()*255+1);
    globG = Math.floor(Math.random()*255+1);
  });
  
  function swap(arr, i1, i2){
      var temp = arr[i1];
      arr[i1] = arr[i2];
      arr[i2] = temp;
  }
  
  function appendArr(baseArr, arr){
    var temp = [];
    for (var i=0; i<arr.length; i++){
      temp.push(arr[i]);
    }
    baseArr.push(temp);
  }
  
  function heapify(arr,n,x){
      var max = x;
      var l = 2*x+1;
      var r = 2*x+2;
      if (l<n && arr[l] > arr[x]) max = l;
      if (r<n && arr[r] > arr[max]) max = r;
      if (max != x){
          swap(arr, x, max);
      appendArr(heapArrCopies, arr);
      appendArr(heapSwaps, [x, max]);
          heapify(arr,n,max);
      }
  }
  
  function printTree(arr){
      var prtStr = "";
      var max = 1;
      var counter = 0;
      for (var i=0; i<arr.length; i++){
          if (counter>=max){
              prtStr += "\n";
              counter = 0;
              max*=2;
          }
          prtStr += arr[i] + ' ';
          counter++;
      }
      console.log(prtStr);
  }
  
  // function heapSort(arr){
  // 	for (var i=Math.floor(arr.length/2-1); i>=0; i--){ // builds max heap
  //      heapify(arr, arr.length, i);
  // 	}
  // 	for (var i=arr.length-1; i>=0; i--){
  // 		swap(arr,0,i);
  //     appendArr(heapArrCopies, arr);
  //     appendArr(heapSwaps, [0,i]);
  // 		heapify(arr,i,0);
  // 	}
  // }
  
  var heapArrCopies = [];
  var heapSwaps = [];
  
  function animHandlerHeap(){
    if (heapArrCopies[animIndex] == undefined){
      updateHtml(globalArr);
      updateTree(globalArr);
      resetAnimation(false);
      return;
    }
    updateHtml(heapArrCopies[animIndex]);
    updateTree(heapArrCopies[animIndex]);
    $("#bar"+heapSwaps[animIndex][0]).css("background-color", "#00f");
    $("#bar"+heapSwaps[animIndex][1]).css("background-color", "#0f0");
    $(".bar"+heapSwaps[animIndex][0]).css("background-color", "#00f");
    $(".bar"+heapSwaps[animIndex][1]).css("background-color", "#0f0");
    animIndex++;
  }
  
  // $("#heap-sort").on("click", () => {
  //   heapSort(globalArr);
  //   $("h4").html("Tree Layout:");
  //   intervalId = window.setInterval(animHandlerHeap, animDelay);
  // });
  
  var bubbleArrCopies = [];
  var bubbleColors = [];
  function bubbleSort(arr){
      var end = arr.length;
    var hasSwapped = false;
      while (end > 2) {
      hasSwapped = false;
          for (var i=0; i<end-1; i++){
              if (arr[i]>arr[i+1]){
          swap(arr,i,i+1);
          hasSwapped = true;
        }
        appendArr(bubbleArrCopies, arr);
        appendArr(bubbleColors, [i, i+1]);
          }
      if (!hasSwapped) break;
          end--;
      }
  }
  
  function animHandlerBubble(){
    if (bubbleArrCopies[animIndex] == undefined){
      updateHtml(globalArr);
      resetAnimation();
      return;
    }
    updateHtml(bubbleArrCopies[animIndex]);
    $("#bar"+bubbleColors[animIndex][0]).css("background-color", "#00f");
    $("#bar"+bubbleColors[animIndex][1]).css("background-color", "#0f0");
    animIndex++;
  }
  
  $("#bubble-sort").on("click", () => {
    bubbleSort(globalArr);
    intervalId = window.setInterval(animHandlerBubble, animDelay);
  });